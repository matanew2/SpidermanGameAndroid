package com.example.spidermangame;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

}
